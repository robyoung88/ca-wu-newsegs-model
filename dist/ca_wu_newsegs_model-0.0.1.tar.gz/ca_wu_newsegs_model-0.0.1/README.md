# NewSEGS Model

## Introduction 
The North Wales Social Housing Newbuild on-Site Energy Generation and Storage (NewSEGS) project aims to identify and optimise opportunities for self-supply of renewable energy in newbuild social housing in North Wales.

The NewSEGS-modelling project builds on the work of Dr David Sprake to produce estimates of the financial performance of a local energy system.

## Getting Started

## Supported platforms
This program has been tested on the following platforms:

- Python 3.13 running on Microsoft Windows 10

## Installing dependencies
In order to run this model, it is recommended that you set up a virtual execution environment. Using conda or miniconda, it is recommended you do so from the relevant `environment.yml` file using the command:

```
conda env create -f environment.yml
```

## Running calculations

**TODO**

## Model Concept

The NewSEGS model consists of four modules

- **Module 1 - Generation**
- **Module 2 - Grid**
- **Module 3 - Consumption**
- **Module 4 - Storage**

These four modules must be defined for a coincident time period, as one of the key considerations of the model is that short-term local environmental conditions determine the value of both generation and consumption, and may impact storage performance; correlated wider environmental conditions determine the cost of imported energy from the grid, and the sale price of electricity to the grid.

As such, wrapping these four modules is an overall Model configuration, which includes access to environmental data.

## Licence
This software is available under the [MIT License](LICENCE).
