"""
A simplified app to test handling circular callbacks for queue management.

In the initial attempt, the following structure was followed.

Button input converted to event
->
event passed to queue manager, which is also triggered by a postdispatch callback
->
queue manager adds events to queue, then pops off top of queue and outputs to a dispatched store
-> 
dispatcher watches the dispatched store, and executes the event as it arrives. 
It then updates the postdispatch callback, triggering the queue manager again.
-> 
If the queue manager is out of events in the queue, it outputs a no update and the dispatcher is not triggered.

However, this cannot work at the present time (May 2026)

Instead, we will use an Interval to periodically fire the queue manager.
"""
import datetime
import json

import dash
import dash_bootstrap_components as dbc

BOOTSTRAP_STYLESHEETS = [dbc.themes.BOOTSTRAP, dbc.icons.BOOTSTRAP]

def create_layout():
    content = dash.html.Div([
        dbc.Row(
            [
                dbc.Col(
                    dbc.Button(
                        "Add five things",
                        id = 'btn-addthings'
                    )
                ),
                dbc.Col(
                    dash.html.Div([],id = 'div-result-holder')
                ),
                dash.dcc.Store(id = 'prequeue'),
                dash.dcc.Store(id = 'queue'),
                dash.dcc.Store(id = 'dispatched'),
                dash.dcc.Store(id = 'postdispatch'),
                dash.dcc.Interval(id = 'queuetrigger', interval = 1000, disabled = True)
            ]
        )
    ])

    return dbc.Container(content, fluid = False)

def deferred_callback_dispatch(event):
    if event is None:
        return (
            dash.no_update, 
        #    dash.no_update
        )
 
    print(dash.ctx.triggered)
    print(event)
    print(json.loads(event))

    patched_result = dash.Patch()
    patched_result.append(
            dash.html.Span(json.loads(event), style={'margin': '10px'})
        )

    return patched_result
        #str(datetime.datetime.now())

def add_callbacks(app):
    @app.callback(
        dash.Output('prequeue', 'data'),
        dash.Input('btn-addthings', 'n_clicks'),
        prevent_initial_call = True,
    )
    def btn_press(n_clicks):
        if n_clicks is None:
            return dash.no_update
        
        now = str(datetime.datetime.now())

        return [json.dumps(str(x+1) + " - " + now) for x in range(5)]
        #return json.dumps(
        #    [str(x+1) + " - " + now for x in range(5)]
        #)
    
    @app.callback(
        dash.Output('queue', 'data'),
        dash.Output('dispatched', 'data'),
        dash.Output('queuetrigger', 'disabled'),
        dash.Input('prequeue', 'data'),
        dash.Input('queuetrigger', 'n_intervals'),
        #dash.Input('postdispatch', 'data'),
        dash.State('queue', 'data'),
        prevent_initial_call = True,
    )
    def queueman(
        prequeue, 
        queuetrigger,
        #postdispatch, 
        queue,
        ):
        print(queue)
        if queue is None:
            queue = []
        
        print(dash.ctx.triggered_id)

        if dash.ctx.triggered_id == 'prequeue':
            #to_add = json.loads(prequeue)
            to_add = prequeue
            queue += to_add
        
        if len(queue) == 0:
            return (
                [],
                #json.dumps(queue),
                dash.no_update,
                True
            )
        
        #to_dispatch = queue.pop(0)
        to_dispatch = queue.pop(0)
        return (
            #json.dumps(queue),
            queue,
            #json.dumps(to_dispatch),
            to_dispatch,
            False
        )
    
    @app.callback(
        dash.Output('div-result-holder', 'children'),
        #dash.Output('postdispatch', 'data'),
        dash.Input('dispatched', 'data'),
        prevent_initial_call = True,
    )
    def dispatcher(event):
        return deferred_callback_dispatch(event)
    
    return app

def serve_layout():
    return dash.html.Div([
        create_layout()
    ])

def create_app(external_stylesheets = None):
    if external_stylesheets is None:
        external_stylesheets = BOOTSTRAP_STYLESHEETS
    else:
        # Always add on bootstrap
        external_stylesheets += BOOTSTRAP_STYLESHEETS
    
    app = dash.Dash(
        __name__,
        title = 'Simple App',
        external_stylesheets = external_stylesheets
    )
    app.layout = serve_layout

    app = add_callbacks(app)

    return app