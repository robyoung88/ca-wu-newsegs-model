"""
A simplified app to test architectures for using a background callback manager
"""
import time
import datetime
import uuid

import dash
import dash_bootstrap_components as dbc
import diskcache

from config import settings

cache = diskcache.Cache(settings.get('DiskcacheCache', './cache'))
background_callback_manager = dash.DiskcacheManager(cache)

BOOTSTRAP_STYLESHEETS = [dbc.themes.BOOTSTRAP, dbc.icons.BOOTSTRAP]

def create_layout():
    """
    The layout for the app.
    """
    content = dash.html.Div([
        dbc.Row(
            [
                dbc.Col(
                    dbc.Button(
                        "A button",
                        id = 'btn-1'
                    )
                ),
                dbc.Col(
                    dash.html.Div(id = 'div-result-holder')
                ),
                dash.dcc.Store(id = 'stor-data'),
            ]   
        )
    ])

    return dbc.Container(content, fluid=False)

def add_callbacks(app):
    @app.callback(
        dash.Output('stor-data', 'data'),
        dash.Input('btn-1', 'n_clicks'),
        prevent_initial_call = True,
    )
    def btn_press(n_clicks):
        if n_clicks is None:
            return dash.no_update
        
        return '1'
    
    @app.callback(
        dash.Output('div-result-holder', 'children'),
        dash.Input('stor-data', 'data'),
        prevent_initial_call = True,
        background = True,
        manager = background_callback_manager,
    )
    def do_process(input):
        time.sleep(5)
        return str(datetime.datetime.now())
    
    return app

def serve_layout():
    session_id = str(uuid.uuid4)

    return dash.html.Div([
        create_layout(),
        dash.dcc.Store(data=session_id, id = 'session-id')
    ])

def create_app(external_stylesheets = None):
    if external_stylesheets is None:
        external_stylesheets = BOOTSTRAP_STYLESHEETS
    else:
        # Always add on bootstrap
        external_stylesheets += BOOTSTRAP_STYLESHEETS
    
    app = dash.Dash(
        __name__,
        title = 'Simple App',
        external_stylesheets = external_stylesheets
    )
    app.layout = serve_layout

    app = add_callbacks(app)

    return app