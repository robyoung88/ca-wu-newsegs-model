"""
A simplified app to test architectures for using a background callback manager

Includes background callback caching and running of a newsegs model
"""
import time
import datetime
import uuid

import dash
import dash_bootstrap_components as dbc
import diskcache

from config import settings

from src.newsegsmodel import sprakemodel

cache = diskcache.Cache(settings.get('DiskcacheCache', './cache'))
background_callback_manager = dash.DiskcacheManager(cache, cache_by = [lambda: launch_uid])

BOOTSTRAP_STYLESHEETS = [dbc.themes.BOOTSTRAP, dbc.icons.BOOTSTRAP]

launch_uid = uuid.uuid4()

# Whether we use the dictionary with a background callback manager,
# or the cache in either case, we will need to explicitly send the
# model to the store before and after calculation.
# This is because the cache is immutable, and is the only way to move
# the model between processes.
models = {}
#models = cache

def spawn_model():
    return sprakemodel.SprakeModel.from_none()

def get_model(model_id):
    # Declare models as global in case we need to spawn?
    #global models
    mdl = models.get(model_id, None)
    if mdl is None:
        mdl = spawn_model()
        models[model_id] = mdl
    return mdl

def model_to_cache(model_id):
    mdl = get_model(model_id)
    cache[model_id] = mdl

def model_from_cache(model_id):
    mdl = cache.get(model_id)
    return mdl

def create_layout():
    """
    The layout for the app.
    """
    content = dash.html.Div([
        dbc.Row(
            [
                dbc.Col(
                    dbc.Button(
                        "A button",
                        id = 'btn-1'
                    )
                ),
                dbc.Col(
                    dash.html.Div(id = 'div-result-holder')
                ),
                dbc.Col(
                    dash.html.Div(id = 'div-local-result-holder')
                ),
                dash.dcc.Store(id = 'stor-data'),
                dash.dcc.Store(id = 'run-trigger'),
            ]   
        )
    ])

    return dbc.Container(content, fluid=False)

def add_callbacks(app):
    @app.callback(
        dash.Output('stor-data', 'data'),
        dash.Input('btn-1', 'n_clicks'),
        prevent_initial_call = True,
    )
    def btn_press(n_clicks):
        if n_clicks is None:
            return dash.no_update
        
        return '1'

    # This intercepts the stor-data change and pushes the model to the cache
    @app.callback(
        dash.Output('run-trigger', 'data'),
        dash.Input('stor-data', 'data'),
        prevent_initial_call = True
    )
    def push_model(input):
        # Ensure model exists
        mdl = get_model(input)
        model_to_cache(input)
        return input
    
    @app.callback(
        dash.Output('div-result-holder', 'children'),
        dash.Input('run-trigger', 'data'),
        dash.State('stor-data', 'data'),
        prevent_initial_call = True,
        background = True,
        manager = background_callback_manager,
        # NB - despite documentation, 'cache_by' cannot go here
    )
    def do_process(_,input):
        # mdl must come from cache
        mdl = model_from_cache(input)
        op = mdl.run()
        models[input] = mdl
        model_to_cache(input)
        return str(datetime.datetime.now()) + " - " + str(op) + ' <br> ' + str(mdl.get_generation_result().meters_to_pandas().describe()) + '  ' + str(mdl.uuid)
    
    @app.callback(
        dash.Output('div-local-result-holder', 'children'),
        dash.Input('div-result-holder', 'children'),
        dash.State('stor-data', 'data'),
        prevent_initial_call = True,
    )
    def do_local_print(_, input):
        # This should really be handled by another in-line callback, but as we have only a single output:
        mdl = model_from_cache(input)
        models[input] = mdl
        mdl = get_model(input)
        return str(datetime.datetime.now()) + " - " + str(hash(mdl)) + ' <br> ' + str(mdl.get_generation_result().meters_to_pandas().describe()) + '  ' + str(mdl.uuid)

    return app

def serve_layout():
    session_id = str(uuid.uuid4)

    return dash.html.Div([
        create_layout(),
        dash.dcc.Store(data=session_id, id = 'session-id')
    ])

def create_app(external_stylesheets = None):
    if external_stylesheets is None:
        external_stylesheets = BOOTSTRAP_STYLESHEETS
    else:
        # Always add on bootstrap
        external_stylesheets += BOOTSTRAP_STYLESHEETS
    
    app = dash.Dash(
        __name__,
        title = 'Simple App',
        external_stylesheets = external_stylesheets
    )
    app.layout = serve_layout

    app = add_callbacks(app)

    return app