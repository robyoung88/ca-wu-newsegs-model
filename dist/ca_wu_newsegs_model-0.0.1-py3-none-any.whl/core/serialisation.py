"""
Classes and mixins related to serialising and unserialising objects
"""
from typing import Any


class SerialiseToDictMixin:
    def to_dict(self):
        return (
            {
                'class': self.__class__.__name__,
            }
            .update(
                {
                    prop: self._represent(value)
                    for prop, value in self.__dict__.items()
                }
            )
        )
    
    def _represent(self, value):
        if isinstance(value, object):
            if hasattr(value, 'to_dict'):
                return value.to_dict() # pyright: ignore[reportAttributeAccessIssue]
            else:
                return str(value)
        else:
            return value
        
    def update(self, config: dict[str, Any]):
        
        
    @classmethod
    def from_dict(cls, config: dict[str, Any]):

