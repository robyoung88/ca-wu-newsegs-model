"""
Registers of classes implementing SerialiseToDictMixin.
"""

def get_newsegscomponent_register():
    from src.newsegsmodel import sprakemodel
    from src.newsegsfinance import sprakefinance
    from src.newsegsvariable import variable

    COMPONENT_CONSTRUCTORS = {
        sprakemodel.SprakeModel.__name__: sprakemodel.SprakeModel,
        sprakefinance.SprakeFinance.__name__: sprakefinance.SprakeFinance,
    }.update(variable.VARIABLE_CONSTRUCTORS)
    
    return COMPONENT_CONSTRUCTORS

def get_newsegsmodule_register():
    from core import newsegsmodule
    import newsegsgeneration
    import newsegsgrid
    import newsegscs

    MODULE_CONSTRUCTORS = {}
    for pymod in [newsegsgeneration, newsegsgrid, newsegscs]:
        for newsegsmodname in pymod.__all__:
            mod = getattr(pymod, newsegsmodname)
            if isinstance(mod, newsegsmodule.NewsegsModule):
                MODULE_CONSTRUCTORS[mod.__name__] = mod
    
    return MODULE_CONSTRUCTORS

if __name__=='__main__':
    modreg = get_newsegsmodule_register()
    for k, v in modreg.items():
        print (k)
