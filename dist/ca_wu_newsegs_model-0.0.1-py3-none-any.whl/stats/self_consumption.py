"""
Summarise self-consumption data.
"""
import copy
from collections.abc import Iterable

import numpy as np
import numpy.typing as npt
import pandas as pd

from src.core.newsegsmodule import filter_meters, ABCNewsegsModuleResult
from src.stats.core import assign_year_index, assign_season_index
from src.newsegsgeneration.newsegsgeneration import get_generation_meters

def self_consume(generation: npt.NDArray, 
                 consumption: npt.NDArray
) -> npt.NDArray:
    """
    For meter series, the quantity of generation self-consumed.
    """
    return np.where(
        generation > consumption,
        consumption,
        generation
    )

def as_iterable(varlist: str|Iterable|None):
    if varlist is None:
        return []
    if isinstance(varlist, str):
        return [varlist]
    return varlist

def selfcons_summary(df: pd.DataFrame,
                     unit_grouping_variables: str|Iterable|None = None,
                     agg_grouping_variables: str|Iterable|None = None
                     ):
    unit_grouping_variables = as_iterable(unit_grouping_variables)
    agg_grouping_variables = as_iterable(agg_grouping_variables)

    init_grouping_variables = (
        ['generator'] 
        + unit_grouping_variables 
        + agg_grouping_variables
    )
    init_grouping_variables = list(set(init_grouping_variables))

    precompute = (
        df
        .groupby(init_grouping_variables)
        .agg('sum')
        .assign(
            prop_gen_self_consumption = lambda df: \
                df['self_consumption'] / df['production']
        )
    )

    if len(unit_grouping_variables) == 0 and len(agg_grouping_variables) == 0:
        # No further disaggregation - makes sense to return as-is
        precompute.columns = pd.MultiIndex.from_arrays([precompute.columns, ['sum']*len(precompute.columns)])
        return precompute
    
    if len(agg_grouping_variables) == 0:
        init_grouping_variables.remove('generator')
        return(
            precompute
            .reset_index()
            .drop(columns=init_grouping_variables)
            .groupby('generator')
            .agg(['mean', 'min', 'max'])
        )
    
    if len(unit_grouping_variables) == 0:
        precompute.columns = pd.MultiIndex.from_arrays([precompute.columns, ['sum']*len(precompute.columns)])
        return precompute
    
    keepvars = ['generator'] + agg_grouping_variables
    keepvars = list(set(keepvars))
    dropvars = copy.copy(init_grouping_variables)
    for v in init_grouping_variables:
        if v in keepvars:
            dropvars.remove(v)

    return(
            precompute
            .reset_index()
            .drop(columns=dropvars)
            .groupby(keepvars)
            .agg(['mean', 'min', 'max'])
        )

def to_self_consumption(
    consumption_storage_result: ABCNewsegsModuleResult,
    generation_result: ABCNewsegsModuleResult
):
    """
    Convert model results to a self-consumption dataframe
    """
    conr = consumption_storage_result
    genr = generation_result

    cons_meters = filter_meters(conr, 'load')

    cons_data = (
        conr.meters_to_pandas()
        .loc[:, cons_meters]
        .apply(sum, axis=1)
        .rename('consumption')
    )

    gen_data = get_generation_meters(genr)

    selfcons_data = (
        gen_data
        .apply(
            lambda col: self_consume(col, cons_data)
        )
    )

    # Before we do the pivot, we might as well get the season indices so that we can
    # bind them on afterwards
    time_indices = (
        gen_data.index
        .to_frame()
        .rename(columns={0:'datetime'})
        .pipe(assign_year_index)
        .pipe(assign_season_index)
        .set_index('datetime')
    )

    pivoted = (
        gen_data
        .melt(
            var_name='generator',
            value_name='production',
            ignore_index=False
        )
        .reset_index(names='datetime')
        .set_index(['datetime', 'generator'])
        .join(
            selfcons_data
            .melt(
                var_name='generator',
                value_name='self_consumption',
                ignore_index=False
            )
            .reset_index(names='datetime')
            .set_index(['datetime', 'generator'])
        )
        .reset_index()
        .set_index('datetime')
        .join(time_indices)
        .query('year_index > -1')
    )

    return pivoted
