from src.newsegsgeneration.newsegsgeneration import NewsegsGeneration
from src.newsegsgeneration.sprakegeneration import SprakeGeneration
__all__ = ['NewsegsGeneration', 'SprakeGeneration']
